import { Image } from 'react-bootstrap';

function Error404() {
    return (
        <div className="container" style={{textAlign: "center"}}>
            <Image src="http://store.picbg.net/pubpic/32/E3/c2b456c4b2d532e3.jpg" fluid />
        </div>
    )
}

export default Error404;