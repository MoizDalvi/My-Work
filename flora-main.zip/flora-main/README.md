
1. install yarn globaly https://stackoverflow.com/questions/62898770/how-do-i-switch-from-npm-to-yarn-in-my-project
2. install nodemon globalyn https://www.npmjs.com/package/nodemon?activeTab=readme
3. edit script in jason https://stackoverflow.com/questions/69665222/node-js-17-0-1-gatsby-error-digital-envelope-routinesunsupported-err-os
